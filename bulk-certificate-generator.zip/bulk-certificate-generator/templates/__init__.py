"""Certificate templates package."""
